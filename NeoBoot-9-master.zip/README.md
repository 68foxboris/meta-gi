# NeoBoot-9


Pierwsza instalacja neoboot-a

Uruchom poniższą komendę w terminalu wspieranego tunera:
#

opkg update 

opkg install curl 

curl -kLs https://raw.githubusercontent.com/gutosie/NeoBoot-9/master/iNB.sh|sh
#

Inny sposób instalacji, jeśli narzędzie curl nie zadziała poprawnie, to proszę spróbować polecenia :


opkg update

cd /tmp

wget https://raw.githubusercontent.com/gutosie/NeoBoot-9/master/iNB.sh

chmod 0755 /tmp/iNB.sh

/tmp/iNB.sh
#

UWAGA!!! 
 Redystrybucja wersji programu i dokonywania modyfikacji JEST DOZWOLONE, pod warunkiem zachowania niniejszej informacji o prawach autorskich. 

Autor NIE ponosi JAKIEJKOLWIEK odpowiedzialności za skutki użytkowania tego programu oraz za wykorzystanie zawartych tu informacji.

Instalację i modyfikacje przeprowadzasz na wlasne ryzyko!!! Przed instalacją lub aktualizacją Neoboot przeczytaj uważnie wszystkie informacje zawarte tu i w wtyczce. !

Dziękuję wszystkim kolegom wpierającym projekt neoboot.



pozdrawiam gutosie


