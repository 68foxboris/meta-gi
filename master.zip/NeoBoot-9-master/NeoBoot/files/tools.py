# -*- coding: utf-8 -*-
# system modules
 
from Plugins.Extensions.NeoBoot.__init__ import _  
import codecs
from enigma import getDesktop
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.ConfigList import ConfigListScreen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.config import getConfigListEntry, config, ConfigYesNo, ConfigText, ConfigSelection, NoSave
from Plugins.Extensions.NeoBoot.plugin import Plugins, PLUGINVERSION, UPDATEVERSION
from Plugins.Plugin import PluginDescriptor
from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, fileExists, pathExists, createDir, fileCheck
from os import system, listdir, mkdir, chdir, getcwd, rename as os_rename, remove as os_remove, popen
from os.path import dirname, isdir, isdir as os_isdir
from enigma import eTimer
from stbbranding import getNeoLocation, getImageNeoBoot, getKernelVersionString, getBoxHostName, getCPUtype, getBoxVuModel, getTunerModel, getCPUSoC, getImageATv 
import os
import time
import sys
import struct, shutil
if fileExists('/etc/vtiversion.info') or fileExists('/usr/lib/python3.8') and fileExists('/.multinfo'):   
    from Screens.Console import Console                   
else:
    from Plugins.Extensions.NeoBoot.files.neoconsole import Console
LinkNeoBoot = '/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot'                                              
neoboot = getNeoLocation()    
       
def getDS():
    s = getDesktop(0).size()
    return (s.width(), s.height())

def isFHD():
    desktopSize = getDS()
    return desktopSize[0] == 1920

def isHD():
    desktopSize = getDS()
    return desktopSize[0] >= 1280 and desktopSize[0] < 1920

def isUHD():
    desktopSize = getDS()
    return desktopSize[0] >= 1920 and desktopSize[0] < 3840  
 

def getKernelVersion():
    try:
        return open('/proc/version', 'r').read().split(' ', 4)[2].split('-', 2)[0]
    except:
        return _('unknown')            

def getCPUtype():
    cpu='UNKNOWN'
    if os.path.exists('/proc/cpuinfo'):
        with open('/proc/cpuinfo', 'r') as f:
            lines = f.read()
            f.close()
        if lines.find('ARMv7') != -1:
            cpu='ARMv7'
        elif lines.find('mips') != -1:
            cpu='MIPS'
    return cpu

if os.path.exists('/etc/hostname'):
    with open('/etc/hostname', 'r') as f:
        myboxname = f.readline().strip()
        f.close()            
           
if os.path.exists('/proc/stb/info/vumodel'):
    with open('/proc/stb/info/vumodel', 'r') as f:
        vumodel = f.readline().strip()
        f.close() 

if os.path.exists('/proc/stb/info/boxtype'):
    with open('/proc/stb/info/boxtype', 'r') as f:
        boxtype = f.readline().strip()
        f.close() 

class BoundFunction:
    __module__ = __name__

    def __init__(self, fnc, *args):
        self.fnc = fnc
        self.args = args

    def __call__(self):
        self.fnc(*self.args)             


class MBTools(Screen):
    if isFHD():
        skin = """<screen name="MBTools" position="70,93" size="910,938" title="NeoBoot tools">  
          <eLabel position="20,68" size="890,2" backgroundColor="blue" foregroundColor="blue" name="linia" />
          <eLabel position="20,935" size="890,2" backgroundColor="blue" foregroundColor="blue" name="linia" />
          <ePixmap position="25,-1" size="45,65" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/updown.png" alphatest="on" />        
          <eLabel backgroundColor="background" font="baslk; 30" foregroundColor="yellow" position="293,2" size="275,57" text="Menu list NEOBoot" />
          <widget source="list" render="Listbox" position="20,75" size="885,847" scrollbarMode="showOnDemand">
          <convert type="TemplatedMultiContent">\n                \t\t{"template": [\n                    \t\t\tMultiContentEntryText(pos = (50, 1), size = (920, 56), flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),\n                    \t\t\tMultiContentEntryPixmapAlphaTest(pos = (6, 4), size = (66, 66), png = 1),\n                    \t\t\t],\n                    \t\t\t"fonts": [gFont("Regular", 35)],\n                    \t\t\t"itemHeight": 60\n                \t\t}\n            \t\t</convert>
          </widget>      
          </screen>"""
    else:
        skin = '\n <screen position="center,center" size="590,330" title="NeoBoot tools">\n\t\t<widget source="list" render="Listbox" position="10,16" size="570,300" scrollbarMode="showOnDemand" >\n\t\t\t<convert type="TemplatedMultiContent">\n                \t\t{"template": [\n                    \t\t\tMultiContentEntryText(pos = (50, 1), size = (520, 36), flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),\n                    \t\t\tMultiContentEntryPixmapAlphaTest(pos = (4, 2), size = (36, 36), png = 1),\n                    \t\t\t],\n                    \t\t\t"fonts": [gFont("Regular", 22)],\n                    \t\t\t"itemHeight": 36\n                \t\t}\n            \t\t</convert>\n\t\t</widget>\n        </screen>'
    __module__ = __name__

    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = []
        self['list'] = List(self.list)
        self.updateList()
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'ok': self.KeyOk,
         'back': self.close})

    def updateList(self):                       
        self.list = []
        mypath = '' +LinkNeoBoot+ ''
        if not fileExists(mypath + 'icons'):
            mypixmap = '' +LinkNeoBoot+ '/images/ok.png'
        png = LoadPixmap(mypixmap)

        res = (_ ('Make a copy of the image from NeoBoot'), png, 0)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Restore a copy of the image to NeoBoot'), png, 1)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('Device manager'), png, 2)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('Delete image ZIP from the ImagesUpload directory'), png, 3)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('NeoBoot Backup'), png, 4)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Uninstall NeoBoot'), png, 5)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Reinstall NeoBoot'), png, 6)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('Update NeoBoot on all images.'), png, 7)
        self.list.append (res)
        self ['list']. list = self.list
                
        res = (_ ('Update TV list on installed image.'), png, 8)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Update IPTVPlayer on installed image.'), png, 9)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('Removing the root password.'), png, 10)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Check the correctness of neoboot installation'), png, 11)
        self.list.append (res)
        self ['list']. list = self.list
        
        res = (_ ('Skin change'), png, 12)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Block or unlock skins.'), png, 13)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Mount Internal Flash'), png, 14)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Deleting languages'), png, 15)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Add cams to feed for OpenATV '), png, 16)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('Supported sat tuners'), png, 17)
        self.list.append (res)
        self ['list']. list = self.list

        res = (_ ('NeoBoot Information'), png, 18)
        self.list.append (res)
        self ['list']. list = self.list


    def KeyOk(self):
        self.sel = self['list'].getCurrent()
        if self.sel:
            self.sel = self.sel[2]
        if self.sel == 0 and self.session.open(MBBackup):
            pass
        if self.sel == 1 and self.session.open(MBRestore):
            pass
        if self.sel == 2 and self.session.open(MenagerDevices):
            pass
        if self.sel == 3 and self.session.open(MBDeleUpload):
            pass
        if self.sel == 4 and self.session.open(BackupMultiboot):
            pass
        if self.sel == 5 and self.session.open(UnistallMultiboot):
            pass
        if self.sel == 6 and self.session.open(ReinstllNeoBoot):
            pass
        if self.sel == 7 and self.session.open(UpdateNeoBoot):
            pass
        if self.sel == 8 and self.session.open(ListTv):
            pass
        if self.sel == 9 and self.session.open(IPTVPlayer):
            pass
        if self.sel == 10 and self.session.open(SetPasswd): 
            pass
        if self.sel == 11 and self.session.open(CheckInstall): 
            pass                        
        if self.sel == 12 and self.session.open(SkinChange):
            pass
        if self.sel == 13 and self.session.open(BlocUnblockImageSkin):
            pass                                    
        if self.sel == 14 and self.session.open(InternalFlash):               
            pass
        if self.sel == 15 and self.session.open(DeletingLanguages):               
            pass
        if self.sel == 16 and self.session.open(ATVcamfeed):               
            pass
        if self.sel == 17 and self.session.open(TunerInfo):
            pass
        if self.sel == 18 and self.session.open(MultiBootMyHelp):
            pass

class MBBackup(Screen):
    if isFHD():
        skin = """ <screen name="MBBackupFHD" title="Backup image from NeoBoot" position="center,center" size="850,750">            
          <widget name="lab1" position="17,5" size="819, 62" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />            
          <widget name="lab2" position="17,75" size="819,68" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />
          <widget name="lab3" position="17,150" size="819,85" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />           
          <widget source="list" render="Listbox" itemHeight="40" font="Regular;21" position="23,268" zPosition="1" size="829,405" scrollbarWidth="8" scrollbarMode="showOnDemand" transparent="1">           
          <convert type="StringList" font="Regular;35" />          
          </widget>           
          <ePixmap position="270,705" size="34, 34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />          
          <widget name="key_red" position="325,705" zPosition="2" size="520,35" font="baslk;30" halign="left" valign="center" backgroundColor="#f23d21" transparent="1" foregroundColor="#f23d21" />            
        </screen>"""
    else:
        skin = """ <screen name="MBBackupHD" position="center,center" size="700,550" title="Backup the image from NeoBoot">            
        <widget name="lab1" position="20,20" size="660,30" font="Regular;24" halign="center" valign="center" transparent="1" />             
        <widget name="lab2" position="20,50" size="660,30" font="Regular;24" halign="center" valign="center" transparent="1" />             
        <widget name="lab3" position="20,100" size="660,30" font="Regular;22" halign="center" valign="center" transparent="1" />            
         <widget source="list" render="Listbox" position="40,141" zPosition="1" size="620,349" scrollbarMode="showOnDemand" transparent="1">\           
          <convert type="StringList" />
          </widget>\n<ePixmap position="272,498" size="140,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/redcor.png" alphatest="on" zPosition="1" />           
          <widget name="key_red" position="270,500" zPosition="2" size="390,40" font="Regular;20" halign="left" valign="center" backgroundColor="red" transparent="1" />            
          </screen>"""   

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label('')
        self['lab2'] = Label('')
        self['lab3'] = Label(_('Choose the image you want to make a copy of'))
        self['key_red'] = Label(_('Backup'))
        self['list'] = List([])
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'ok': self.backupImage,
         'red': self.backupImage})
        if pathExists('/media/usb/ImageBoot'):
            neoboot = 'usb'
        elif pathExists('/media/hdd/ImageBoot'):
            neoboot = 'hdd' 
        self.backupdir = '/media/' + neoboot + '/CopyImageNEO' 
        self.availablespace = '0'
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        if pathExists('/media/usb/ImageBoot'):
            neoboot = 'usb'
        elif pathExists('/media/hdd/ImageBoot'):
            neoboot = 'hdd' 
        device = '/media/' + neoboot + '' 
        usfree = '0'
        devicelist = ['cf',
         'hdd',
         'card',
         'usb',
         'usb2']
        for d in devicelist:
            test = '/media/' + d + '/ImageBoot/.neonextboot'
            if fileExists(test):
                device = '/media/' + d

        rc = system('df > /tmp/ninfo.tmp')
        f = open('/proc/mounts', 'r')
        for line in f.readlines():
            if line.find('/hdd') != -1:
                self.backupdir = '/media/' + neoboot + '/CopyImageNEO'
                device = '/media/' + neoboot + '' 

        f.close()
        if pathExists(self.backupdir) == 0 and createDir(self.backupdir):
            pass
        if fileExists('/tmp/ninfo.tmp'):
            f = open('/tmp/ninfo.tmp', 'r')
            for line in f.readlines():
                line = line.replace('part1', ' ')
                parts = line.strip().split()
                totsp = len(parts) - 1
                if parts[totsp] == device:
                    if totsp == 5:
                        usfree = parts[3]
                    else:
                        usfree = parts[2]
                    break

            f.close()
            os_remove('/tmp/ninfo.tmp')
        self.availablespace = usfree[0:-3]
        strview = _('You have the following images installed')
        self['lab1'].setText(strview)
        strview = _('You still have free: ') + self.availablespace + ' MB'
        self['lab2'].setText(strview)
        imageslist = ['Flash']
        for fn in listdir('/media/' + neoboot + '/ImageBoot'):
            dirfile = '/media/' + neoboot + '/ImageBoot/' + fn
            if os_isdir(dirfile) and imageslist.append(fn):
                pass

        self['list'].list = imageslist

    def backupImage(self):
        if not fileExists('/.multinfo'):
            self.backupImage2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def backupImage2(self):
        image = self['list'].getCurrent()
        if image:
            self.backimage = image.strip()
            myerror = ''
            if self.backimage == 'Flash':
                myerror = _('Unfortunately you cannot backup from flash with this plugin. \nInstall backupsuite to a copy of the image from flash memory.')
            if int(self.availablespace) < 150:
                myerror = _('There is no space to make a copy of the image. You need 150 Mb of free space for copying the image.')
            if myerror == '':
                message = (_('Make copies of the image: %s now ?') % image)            
                ybox = self.session.openWithCallback(self.dobackupImage, MessageBox, message, MessageBox.TYPE_YESNO)
                ybox.setTitle(_('Backup confirmation'))
            else:
                self.session.open(MessageBox, myerror, MessageBox.TYPE_INFO)

    def dobackupImage(self, answer):
        if answer is True:
            if pathExists('/media/usb/ImageBoot'):
                neoboot = 'usb'
            elif pathExists('/media/hdd/ImageBoot'):
                neoboot = 'hdd' 
            cmd = "echo -e '\n\n%s '" % _('Please wait, NeoBoot is working, the backup may take a few moments, the process is in progress ...')
            cmd1 = '/bin/tar -cf ' + self.backupdir + '/' + self.backimage + '.tar /media/' + neoboot + '/ImageBoot/' + self.backimage + '  > /dev/null 2>&1'
            cmd2 = 'mv -f ' + self.backupdir + '/' + self.backimage + '.tar ' + self.backupdir + '/' + self.backimage + '.mb'
            cmd3 = "echo -e '\n\n%s '" % _('NeoBoot: COMPLETE Backup!')
            self.session.open(Console, _('NeoBoot: Image Backup'), [cmd,
             cmd1,
             cmd2,
             cmd3])
            self.close()
        else:
            self.close()


    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()

class MBRestore(Screen):
    __module__ = __name__                                       
    skin = """ <screen name="ReinstllNeoBoot2" title="Reinstll NeoBoot" position="center,center" size="850,626">            
          <widget name="lab1" position="20,15" size="820,50" font="baslk;30" halign="center" valign="center" transparent="1" foregroundColor="#00ffa500" />                      
          <widget source="list" render="Listbox" itemHeight="40" font="Regular;21" position="25,80" zPosition="1" size="815,464" scrollbarMode="showOnDemand" transparent="1">           
          <convert type="StringList" font="Regular;35" />           
          </widget>           
          <ePixmap position="40,570" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />                
          <ePixmap position="525,570" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/green.png" alphatest="blend" zPosition="1" />          
          <widget name="key_red" position="83,570" zPosition="2" size="250,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" />                
          <widget name="key_green" position="579,570" zPosition="2" size="250,35" font="baslk;30" halign="left" valign="center" backgroundColor="green" transparent="1" />         
          </screen>"""

    def __init__(self, session):               
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Choose copy you want to restore or delete.'))
        self['key_red'] = Label(_('Delete file'))
        self['key_green'] = Label(_('Restore'))
        self['list'] = List([])      
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'ok': self.restoreImage,
         'red': self.deleteback,
         'green': self.restoreImage})         
        self.backupdir = '' + getNeoLocation() + 'CopyImageNEO'
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        linesdevice = open('' +LinkNeoBoot+ '/.location', 'r').readlines()
        deviceneo = linesdevice[0][0:-1]
        device = deviceneo
        usfree = '0'
        devicelist = ['cf',
         'CF',
         'hdd',
         'card',
         'sd',
         'SD',
         'usb',
         'USB',
         'usb2']
        for d in devicelist:
            test = '/media/' + d + '/ImageBoot/.neonextboot'
            if fileExists(test):
                device = device + d

        rc = system('df > /tmp/ninfo.tmp')
        f = open('/proc/mounts', 'r')
        for line in f.readlines():
            if line.find('/hdd') != -1:
                self.backupdir = '' + getNeoLocation() + 'CopyImageNEO'
            elif line.find('/usb') != -1:
                self.backupdir = '' + getNeoLocation() + 'CopyImageNEO'
        f.close()  
        if pathExists(self.backupdir) == 0 and createDir(self.backupdir):
            pass
        if fileExists('/tmp/ninfo.tmp'):
            f = open('/tmp/ninfo.tmp', 'r')
            for line in f.readlines():
                line = line.replace('part1', ' ')
                parts = line.strip().split()
                totsp = len(parts) - 1
                if parts[totsp] == device:
                    if totsp == 5:
                        usfree = parts[3]
                    else:
                        usfree = parts[2]
                    break

            f.close()
            os_remove('/tmp/ninfo.tmp')
            
        imageslist = []
        for fn in listdir(self.backupdir):
            imageslist.append(fn)

        self['list'].list = imageslist

    def deleteback(self):
        if not fileExists('/.multinfo'):
            self.deleteback2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def deleteback2(self):
        image = self['list'].getCurrent()
        if image:
            self.delimage = image.strip()
            message = (_('Software selected: %s remove ?') % image )                                 
            ybox = self.session.openWithCallback(self.dodeleteback, MessageBox, message, MessageBox.TYPE_YESNO)
            ybox.setTitle(_('Confirmation of Deletion...'))

    def dodeleteback(self, answer):
        if answer is True:
            cmd = "echo -e '\n\n%s '" % _('NeoBoot - deleting backup files .....')
            cmd1 = 'rm ' + self.backupdir + '/' + self.delimage
            self.session.open(Console, _('NeoBoot: Backup files deleted!'), [cmd, cmd1])
            self.updateInfo()
        else:
            self.close()

    def restoreImage(self):
        if not fileExists('/.multinfo'):
            self.restoreImage2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def restoreImage2(self):
        image = self['list'].getCurrent()
        if image:
            curimage = 'Flash'
            if fileExists('/.neonextboot'):
                f = open('/.neonextboot', 'r')
                curimage = f.readline().strip()
                f.close()
            self.backimage = image.strip()
            imagename = self.backimage[0:-3]
            myerror = ''
            if curimage == imagename:
                myerror = _('Sorry you cannot overwrite the image currently booted from. Please, boot from Flash to restore this backup.')
            if myerror == '':
                message = (_('The required space on the device is 300 MB.\nDo you want to take this image: %s \nnow ?') % image) 
                ybox = self.session.openWithCallback(self.dorestoreImage, MessageBox, message, MessageBox.TYPE_YESNO)
                ybox.setTitle(_('Restore Confirmation'))
            else:
                self.session.open(MessageBox, myerror, MessageBox.TYPE_INFO)

    def dorestoreImage(self, answer):
        if answer is True:
            imagename = self.backimage[0:-3]
            cmd = "echo -e '\n\n%s '" % _('Wait please, NeoBoot is working: ....Restore in progress....')
            cmd1 = 'mv -f ' + self.backupdir + '/' + self.backimage + ' ' + self.backupdir + '/' + imagename + '.tar'
            cmd2 = '/bin/tar -xf ' + self.backupdir + '/' + imagename + '.tar -C /'
            cmd3 = 'mv -f ' + self.backupdir + '/' + imagename + '.tar ' + self.backupdir + '/' + imagename + '.mb'
            cmd4 = 'sync'
            cmd5 = "echo -e '\n\n%s '" % _('Neoboot: Restore COMPLETE !')
            self.session.open(Console, _('NeoBoot: Restore Image'), [cmd,
             cmd1,
             cmd2,
             cmd3,
             cmd4,
             cmd5])
            self.close()
        else:
            self.close()                

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()
            
class MenagerDevices(Screen):
    __module__ = __name__
    skin = """<screen name="MenagerDevices" title="Device manager" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)                    
        self['lab1'] = Label(_('Start the device manager')) 
        self['key_red'] = Label(_('Run'))       
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.MD})

    def MD(self):
        try:
                from Plugins.Extensions.NeoBoot.files.devices import ManagerDevice
                self.session.open(ManagerDevice)
                
        except:
            False


class MBDeleUpload(Screen):
    __module__ = __name__
    skin = """<screen name="MBDeleUpload" title="NeoBoot clear image zip" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Are you sure you want to delete the image from the ImagesUpload directory\nIf you choose the red button on the remote control then you will delete all zip images from the ImagesUpload directory'))
        self['key_red'] = Label(_('Clear'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.usunup})

    def usunup(self):
        message = _('Do you really want to clear')
        ybox = self.session.openWithCallback(self.pedeleup, MessageBox, message, MessageBox.TYPE_YESNO)
        ybox.setTitle(_('Do you really want to clear'))

    def pedeleup(self, answer):
        if answer is True:
            cmd = "echo -e '\n\n%s '" % _('Wait, deleting .....')
            cmd1 = 'rm -r ' + getNeoLocation() + 'ImagesUpload/*.zip' 
            self.session.open(Console, _('Deleting downloaded image zip files ....'), [cmd, cmd1])
            self.close()
        else:
            self.close()


class BackupMultiboot(Screen):
    __module__ = __name__
    skin = """ <screen name="BackupMultiboot" position="center,center" size="700,300" flags="wfNoBorder">    
      <widget source="list" render="Listbox" position="18,31" size="629,300" scrollbarMode="showOnDemand">
      <convert type="TemplatedMultiContent">\n\t\t{"template": [\n\t\t\tMultiContentEntryText(pos = (50, 1), size = (620, 46), flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),\n\t\t\tMultiContentEntryPixmapAlphaTest(pos = (6, 4), size = (46, 46), png = 1),\n\t\t\t],\n\t\t\t"fonts": [gFont("dugme", 30)],\n\t\t\t"itemHeight": 46\n\t\t}\n\t\t</convert>
      </widget>
      <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
      <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
      </screen>"""

    skin = """<screen name="BackupMultiboot" title="NeoBoot backup plugin" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="Regular;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="Regular;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Make complete copy NeoBoot'))
        self['key_red'] = Label(_('Run'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.gobackupneobootplugin})

    def gobackupneobootplugin(self):
            cmd = 'sh ' +LinkNeoBoot+ '/files/neobackup.sh -i'
            self.session.open(Console, _('The backup will be saved to /media/neoboot. Performing ...'), [cmd])
            self.close()


class UnistallMultiboot(Screen):
    __module__ = __name__
    skin = """<screen name="UnistallMultiboot" title="Uninstall NeoBoot" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Remove the plug'))
        self['key_red'] = Label(_('Uninstall'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.checkNeo,
         'red': self.usun})

    def usun(self):
        if not fileExists('/.multinfo'):
            self.usun2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()

    def usun2(self):
        message = _('If you choose Yes, the Multibot image settings will be restored and only uninstalled. You can reinstall it')
        ybox = self.session.openWithCallback(self.reinstallneoboot, MessageBox, message, MessageBox.TYPE_YESNO)
        ybox.setTitle(_('Delete Confirmation'))

    def reinstallneoboot(self, answer):
        if answer is True:
            cmd0 = "echo -e '\nRestoring settings...\n'"
            cmd = 'rm -f /etc/neoimage /etc/imageboot /etc/name'
            cmd1 = 'rm /sbin/neoinit*; sleep 2'
            cmd1a = "echo -e 'Removing boot manager from NeoBoot....\n'"
            cmd2 = 'rm /sbin/init; sleep 2'
            cmd3 = 'ln -sfn /sbin/init.sysvinit /sbin/init'
            cmd4 = 'chmod 777 /sbin/init; sleep 2'
            cmd4a = "echo -e 'NeoBoot restoring media mounts...\n'"
            cmd6 = 'rm -f ' + getNeoLocation() + 'ImageBoot/initneo.log ' + getNeoLocation() + 'ImageBoot/.imagedistro ' + getNeoLocation() + 'ImageBoot/.neonextboot '+ getNeoLocation() + 'ImageBoot/.updateversion '+ getNeoLocation() + 'ImageBoot/.Flash ' + getNeoLocation() + 'ImageBoot/.version ' + getNeoLocation() + 'ImageBoot/NeoInit.log ; sleep 2'
            cmd7 = 'rm -f '+LinkNeoBoot+ '/.location '+LinkNeoBoot+ '/bin/install '+LinkNeoBoot+ '/bin/reading_blkid '+LinkNeoBoot+ '/files/mountpoint.sh '+LinkNeoBoot+ '/files/neo.sh '+LinkNeoBoot+ '/files/neom  '+LinkNeoBoot+ '/.neo_info '
            cmd7a = "echo -e '\n\nUninstalling neoboot...\n'"
            cmd8 = "echo -e '\n\nRestore mount.'"
            cmd9 = "echo -e '\n\nNeoBoot uninstalled, you can do reinstallation.'"
            cmd10 = "echo -e '\n\nNEOBoot  Exit or Back - RESTART GUI NOW !!!'"            
            self.session.open(Console, _('NeoBoot is reinstall...'), [cmd0,
             cmd,
             cmd1,
             cmd1a,
             cmd2,
             cmd3,
             cmd4,
             cmd4a,
             cmd6,
             cmd7,
             cmd7a,
             cmd8,
             cmd9,
             cmd10])            
        else:
            self.close()

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()

    def checkNeo(self):
            if not fileCheck(''+LinkNeoBoot+ '/.location') and not fileCheck(' ' + getNeoLocation() + 'ImageBoot/.neonextboot') :                                                   
                self.restareE2() 
            else:
                self.close()

    def restareE2(self):
        self.session.open(TryQuitMainloop, 3)


class ReinstllNeoBoot(Screen):
    __module__ = __name__
    skin = """<screen name="ReinstllNeoBoot" title="Update NeoBoot" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Restore copy NeoBoot'))
        self['key_red'] = Label(_('Backup'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.reinstallMB})
                                                                                 
    def reinstallMB(self):
            self.session.open(ReinstllNeoBoot2) 
            

class ReinstllNeoBoot2(Screen):
    __module__ = __name__
    skin = """ <screen name="ReinstllNeoBoot2" title="Reinstll NeoBoot" position="center,center" size="850,654">            
          <widget name="lab1" position="20,15" size="820,50" font="baslk;30" halign="center" valign="center" transparent="1" foregroundColor="#00ffa500" />                      
          <widget source="list" render="Listbox" itemHeight="40" font="Regular;21" position="25,94" zPosition="1" size="815,494" scrollbarMode="showOnDemand" transparent="1">           
          <convert type="StringList" font="Regular;35" />           
          </widget>           
          <ePixmap position="40,600" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />                
          <ePixmap position="527,600" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/green.png" alphatest="blend" zPosition="1" />          
          <widget name="key_red" position="85,600" zPosition="2" size="250,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" />                
          <widget name="key_green" position="575,600" zPosition="2" size="250,35" font="baslk;30" halign="left" valign="center" backgroundColor="green" transparent="1" />         
          </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Choose copy you want to restore or delete.'))
        self['key_red'] = Label(_('Delete file'))
        self['key_green'] = Label(_('Restore'))               
        self['list'] = List([])
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'ok': self.restoreImage,
         'green': self.restoreImage,
         'red': self.deleteback})
        self.backupdir = '' + getNeoLocation() + 'CopyNEOBoot'
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        self.backupdir = '' + getNeoLocation() + 'CopyNEOBoot'
        if pathExists(self.backupdir) == 0 and createDir(self.backupdir):
            pass
            
        imageslist = []
        for fn in listdir(self.backupdir):
            imageslist.append(fn)

        self['list'].list = imageslist

    def deleteback(self):
        image = self['list'].getCurrent()
        if image:
            self.delimage = image.strip()
            message = (_('Software selected: %s remove ?') % image )                                    
            ybox = self.session.openWithCallback(self.dodeleteback, MessageBox, message, MessageBox.TYPE_YESNO)
            ybox.setTitle(_('Confirmation of Deletion...'))

    def dodeleteback(self, answer):
        if answer is True:
            cmd = "echo -e '\n\n%s '" % _('NeoBoot - deleting backup files .....')
            cmd1 = 'rm ' + self.backupdir + '/' + self.delimage
            self.session.open(Console, _('NeoBoot: Backup files deleted!'), [cmd, cmd1])
            self.updateInfo()
        else:
            self.close()

    def restoreImage(self):
        image = self['list'].getCurrent()
        myerror = ''
        if myerror == '':
                message = (_('The required space on the device is 300 MB.\nDo you want to take this image: %s \nnow ?') % image) 
                ybox = self.session.openWithCallback(self.dorestoreImage, MessageBox, message, MessageBox.TYPE_YESNO)
                ybox.setTitle(_('Restore Confirmation'))
        else:
                self.session.open(MessageBox, myerror, MessageBox.TYPE_INFO)

    def dorestoreImage(self, answer):
        image = self['list'].getCurrent()            
        if answer is True:
            self.backimage = image.strip()
            imagename = self.backimage[0:-3]
            cmd = "echo -e '\n\n%s '" % _('Wait please, NeoBoot is working: ....Restore in progress....')
            cmd1 = '/bin/tar -xf ' + self.backupdir + '/' + imagename + '.gz -C /'
            cmd2 = "echo -e '\n\n%s '" % _('Neoboot: Restore COMPLETE !')
            self.session.open(Console, _('NeoBoot: Restore Image'), [cmd,
             cmd1,
             cmd2])
            self.close()
        else:
            self.close()


class UpdateNeoBoot(Screen):
    __module__ = __name__
    skin = """<screen name="UpdateNeoBoot" title="Update Upgrade" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Install neobot from flash memory to all images'))
        self['key_red'] = Label(_('Install'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.mbupload})

    def mbupload(self):
        if not fileExists('/.multinfo'):
            self.session.open(MyUpgrade2)                                             
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()

class MyUpgrade2(Screen):
        if isFHD():
            skin = """<screen name="MyUpgrade2" position="30,30" size="900,150" flags="wfNoBorder" title="NeoBoot">
            <widget name="lab1" position="23,17" size="850,109" font="baslk;35" halign="center" valign="center" transparent="1" />
            </screen>"""
        else:
            skin = '<screen position="center,center" size="400,200" title="NeoBoot Upgrade">\n\t\t<widget name="lab1" position="10,10" size="380,180" font="baslk;24" halign="center" valign="center" transparent="1"/>\n\t</screen>'

        def __init__(self, session):
            Screen.__init__(self, session)
            self['lab1'] = Label(_('[NeoBoot]Please wait, updating in progress ...'))
            self.activityTimer = eTimer()
            self.activityTimer.timeout.get().append(self.updateInfo)
            self.onShow.append(self.startShow)

        def startShow(self):
             self.activityTimer.start(10)

        def updateInfo(self):
            self.activityTimer.stop()
            f2 = open('%sImageBoot/.neonextboot' % getNeoLocation(), 'r')
            mypath2 = f2.readline().strip()
            f2.close()
            if mypath2 != 'Flash':
                self.myClose(_('Sorry, NeoBoot can installed or upgraded only when booted from Flash STB'))
                self.close()
            else:
                for fn in listdir('%sImageBoot'  % getNeoLocation() ):
                    dirfile = '%sImageBoot/'  % getNeoLocation() + fn
                    if isdir(dirfile):
                        target = dirfile + '' +LinkNeoBoot+ ''
                        cmd = 'rm -r ' + target + ' > /dev/null 2>&1'
                        system(cmd)
                        cmd = 'cp -r ' +LinkNeoBoot+ ' ' + target
                        system(cmd)

                out = open('%sImageBoot/.version'  % getNeoLocation(), 'w')
                out.write(PLUGINVERSION)
                out.close()
                self.myClose(_('NeoBoot successfully updated. You can restart the plugin now.\nHave fun !!'))

        def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close() 
        

class ListTv(Screen):
    __module__ = __name__
    skin = """<screen name="ListTv" title="Update ListTv NeoBoot" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Copy the tv list with flash on all image'))
        self['key_red'] = Label(_('Install'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.listupload})

    def listupload(self):
        if not fileExists('/.multinfo'):
            self.listupload2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def listupload2(self):
        self.session.open(ListTv2)

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()


class ListTv2(Screen):
    __module__ = __name__

    if isFHD():
        skin = """<screen name="ListTv2" position="30,30" size="900,150" flags="wfNoBorder" title="NeoBoot">
          <widget name="lab1" position="23,17" size="850,109" font="baslk;35" halign="center" valign="center" transparent="1" />
          </screen>"""          
    else:
        skin = '<screen position="center,center" size="400,200" title="NeoBoot ListTv">\n\t\t<widget name="lab1" position="10,10" size="380,180" font="baslk;24" halign="center" valign="center" transparent="1"/>\n\t</screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('NeoBoot: Upgrading in progress\nPlease wait...'))
        self.activityTimer = eTimer()
        self.activityTimer.timeout.get().append(self.updateInfo)
        self.onShow.append(self.startShow)

    def startShow(self):
        self.activityTimer.start(10)

    def updateInfo(self):
        self.activityTimer.stop()
        f2 = open('' + getNeoLocation() + 'ImageBoot/.neonextboot', 'r')
        mypath2 = f2.readline().strip()
        f2.close()
        if mypath2 != 'Flash':
            self.myClose(_('Sorry, NeoBoot can installed or upgraded only when booted from Flash.'))
            self.close()
        else:
            os.system('mv /etc/enigma2 /etc/enigma2.tmp')
            os.system('mkdir -p /etc/enigma2')
            os.system('cp -f /etc/enigma2.tmp/*.tv /etc/enigma2')
            os.system('cp -f /etc/enigma2.tmp/*.radio /etc/enigma2')
            os.system('cp -f /etc/enigma2.tmp/lamedb /etc/enigma2')
            for fn in listdir('' + getNeoLocation() + 'ImageBoot'):
                dirfile = '' + getNeoLocation() + 'ImageBoot/' + fn
                if isdir(dirfile):
                    target = dirfile + '/etc/'
                    cmd = 'cp -r -f /etc/enigma2 ' + target
                    system(cmd)
                    target1 = dirfile + '/etc/tuxbox'
                    cmd = 'cp -r -f /etc/tuxbox/satellites.xml ' + target1
                    system(cmd)
                    target2 = dirfile + '/etc/tuxbox'
                    cmd = 'cp -r -f /etc/tuxbox/terrestrial.xml ' + target2
                    system(cmd)

            os.system('rm -f -R /etc/enigma2')
            os.system('mv /etc/enigma2.tmp /etc/enigma2/')
            self.myClose(_('NeoBoot successfully updated list tv.\nHave fun !!'))

    def myClose(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
        self.close()


class IPTVPlayer(Screen):
    __module__ = __name__
    skin = """<screen name="IPTVPlayer" title="Update IPTVPlayer" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Copy the IPTV Player plugin from flash to all images'))
        self['key_red'] = Label(_('Install'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.IPTVPlayerUpload})

    def IPTVPlayerUpload(self):
        if not fileExists('/.multinfo'):
            self.IPTVPlayerUpload2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def IPTVPlayerUpload2(self):
        self.session.open(IPTVPlayer2)

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()

class IPTVPlayer2(Screen):
    __module__ = __name__

    if isFHD():
        skin = """<screen name="IPTVPlayer2" position="30,30" size="900,150" flags="wfNoBorder" title="NeoBoot">
        <widget name="lab1" position="23,17" size="850,109" font="baslk;35" halign="center" valign="center" transparent="1" />
        </screen>"""
    else:
        skin = '<screen position="center,center" size="400,200" title="IPTVPlayer">\n\t\t<widget name="lab1" position="10,10" size="380,180" font="baslk;24" halign="center" valign="center" transparent="1"/>\n\t</screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('NeoBoot: Upgrading in progress\nPlease wait...'))
        self.activityTimer = eTimer()
        self.activityTimer.timeout.get().append(self.updateInfo)
        self.onShow.append(self.startShow)

    def startShow(self):
        self.activityTimer.start(10)

    def updateInfo(self):
        self.activityTimer.stop()
        f2 = open('' + getNeoLocation() + 'ImageBoot/.neonextboot', 'r')
        mypath2 = f2.readline().strip()
        f2.close()
        if mypath2 != 'Flash':
            self.myClose(_('Sorry, NeoBoot can installed or upgraded only when booted from Flash.'))
            self.close()
        elif not fileExists('/usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer'):
            self.myClose(_('Sorry, IPTVPlayer not found.'))
            self.close()
        else:
            for fn in listdir('' + getNeoLocation() + 'ImageBoot'):
                dirfile = '' + getNeoLocation() + 'ImageBoot/' + fn
                if isdir(dirfile):
                    target = dirfile + '/usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer'
                    cmd = 'rm -r ' + target + ' > /dev/null 2>&1'
                    system(cmd)
                    cmd = 'cp -r /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer ' + target
                    system(cmd)

            self.myClose(_('NeoBoot successfully updated IPTVPlayer.\nHave fun !!'))

    def myClose(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
        self.close()


class SetPasswd(Screen):
    __module__ = __name__
    skin = """<screen name="SetPasswd" title="Password change" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Delete password'))
        self['key_red'] = Label(_('Start'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.passwd})

    def passwd(self):
        os.system('passwd -d root')
        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, _('GUI needs a restart.\nDo you want to Restart the GUI now?'), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()


class CheckInstall(Screen):
    __module__ = __name__
    skin = """<screen name="CheckInstall" title="Check Install" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Checking filesystem...'))
        self['key_red'] = Label(_('Start'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.neocheck})
         
    def neocheck(self):
        if not fileExists('/.multinfo'):
            self.neocheck2()                                            
        else:
            self.myClose(_('Sorry, Neoboot can be installed or upgraded only when booted from Flash'))

    def neocheck2(self):
        try:
            cmd = ' ' +LinkNeoBoot+ '/files/modulecheck.sh'
            self.session.openWithCallback(self.close, Console, _('NeoBoot....'), [cmd,
             cmd]) 
            self.close()

        except:
            False

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()
            

class SkinChange(Screen):
    if isFHD():
        skin = """ <screen name="SkinChange" position="center,center" size="850,746" title="NeoBoot Skin Change">
          <widget name="lab1" position="24, 5" size="819, 62" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />            
          <widget name="lab2" position="22, 82" size="819, 61" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />            
          <widget name="lab3" position="21, 150" size="819, 62" font="baslk;35" halign="center" valign="center" transparent="1" foregroundColor="#99FFFF" />            
          <widget source="list" render="Listbox" itemHeight="40" font="Regular;21" position="20, 218" zPosition="1" size="820, 376" scrollbarMode="showOnDemand" transparent="1"> 
          <convert type="StringList" font="Regular;35" />         
          </widget>           
          <ePixmap position="270,650" size="34, 34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />          
          <widget name="key_red" position="320,650" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />           
        </screen>"""

    else:
        skin = ' <screen position="center,center" size="700,550" title="Backup the image from NeoBoot"><widget name="lab1" position="20,20" size="660,30" font="baslk;24" halign="center" valign="center" transparent="1"/>\n\n             <widget name="lab2" position="20,50" size="660,30" font="baslk;24" halign="center" valign="center" transparent="1"/>\n\n             <widget name="lab3" position="20,100" size="660,30" font="baslk;22" halign="center" valign="center" transparent="1"/>\n \n             <widget source="list" render="Listbox" position="40,130" zPosition="1" size="620,360" scrollbarMode="showOnDemand" transparent="1" >\n\t\t\t\n             <convert type="StringList" />\n</widget>\n<ePixmap position="280,500" size="140,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/redcor.png" alphatest="on" zPosition="1" />\n\n               <widget name="key_red" position="280,500" zPosition="2" size="140,40" font="baslk;20" halign="left" valign="center" backgroundColor="red" transparent="1" />\n\n            </screen>'   

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label('')
        self['lab2'] = Label('')
        self['lab3'] = Label(_('Choose the skin you want to make.'))
        self['key_red'] = Label(_('Change'))
        self['list'] = List([])
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.checkimageskin,
         'ok': self.SkinGO,
         'red': self.SkinGO,
         '9': self.restareE2})
                  
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        self.skindir = '' +LinkNeoBoot+ '/neoskins/'
 
        if pathExists(self.skindir) == 0 and createDir(self.skindir):
            pass

        skinlist = ['default']
        for fn in listdir('' +LinkNeoBoot+ '/neoskins'):
            dirfile = '' +LinkNeoBoot+ '/neoskins/' + fn
            if os_isdir(dirfile) and skinlist.append(fn):
                pass

        self['list'].list = skinlist


    def SkinGO(self):
        skin = self['list'].getCurrent()
        if skin:
            self.selectedskin = skin.strip()
            myerror = ''
            if self.selectedskin == 'default':
                self.DefaultSkin()
            elif myerror == '':
                message = (_('Skin Change: %s now ?') % skin)
                ybox = self.session.openWithCallback(self.doSkinChange, MessageBox, message, MessageBox.TYPE_YESNO)
                ybox.setTitle(_('Skin Change confirmation'))
            else:
                self.session.open(MessageBox, myerror, MessageBox.TYPE_INFO)

#ln -sf "neoskins/default.py" "/usr/lib/enigma2/python/Plugins /Extensions/NeoBoot/skin.py"
    def DefaultSkin(self):
            cmd = "echo -e '\n\n%s '" % _('Please wait, NeoBot is working, skin change is progress...')
            cmd1 = "echo -e '\n\n%s '" % _('NeoBoot: Complete Skin Change!')
#            cmd2 = 'cp -r ' +LinkNeoBoot+ '/neoskins/default.py ' +LinkNeoBoot+ '/skin.py'            
            cmd2 = 'rm -f ' +LinkNeoBoot+ '/usedskin.p*; sleep 2'
            cmd3 = 'ln -sf "neoskins/default.py" "' +LinkNeoBoot+ '/usedskin.py"'
            self.session.open(Console, _('NeoBoot Skin Change'), [cmd, cmd1, cmd2, cmd3])

    def doSkinChange(self, answer):
        if answer is True:
            if getBoxHostName() == 'vuultimo4k':
                system('cp -r ' + LinkNeoBoot + '/images/ultimo4k.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'vusolo4k':
                system('cp -r ' + LinkNeoBoot + '/images/solo4k.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'vuduo4k':
                system('cp -r ' + LinkNeoBoot + '/images/duo4k.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'vuduo4kse':
                system('cp -r ' + LinkNeoBoot + '/images/duo4k.png ' + LinkNeoBoot + '/images/box.png')                               
            elif getBoxHostName() == 'vuuno4k':
                system('cp -r ' + LinkNeoBoot + '/images/uno4k.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'vuuno4kse':
                system('cp -r ' + LinkNeoBoot + '/images/uno4kse.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'vuzero4kse':
                system('cp -r ' + LinkNeoBoot + '/images/zero4kse.png ' + LinkNeoBoot + '/images/box.png')
            elif getBoxHostName() == 'sf4008':
                system('cp -r ' + LinkNeoBoot + '/images/sf4008.png ' + LinkNeoBoot + '/images/box.png')                                
            elif getBoxHostName() == 'ustym4kpro':
                system('cp -r ' + LinkNeoBoot + '/images/ustym4kpro.png ' + LinkNeoBoot + '/images/box.png')                                            
            elif getBoxHostName() == 'h7' or getBoxHostName() == 'zgemmah7' :
                system('cp -r ' + LinkNeoBoot + '/images/zgmmah7.png ' + LinkNeoBoot + '/images/box.png')

            cmd = "echo -e '\n\n%s '" % _('Please wait, NeoBot is working, skin change is progress...')
            cmd1 = 'rm -f ' +LinkNeoBoot+ '/usedskin.p*; sleep 2'            
            cmd2 = 'sleep 2; cp -r ' + self.skindir + '/' + self.selectedskin + '/*.py ' +LinkNeoBoot+ '/usedskin.py'
            cmd3 = "echo -e '\n\n%s '" % _('NeoBoot: Complete Skin Change!')   
            cmd4 = "echo -e '\n\n%s '" % _('To use the new skin please restart enigma2')  
            self.session.open(Console, _('NeoBoot Skin Change'), [cmd, cmd1, cmd2, cmd3, cmd4])
        else:
            self.close()

    def checkimageskin(self):
            if fileCheck('/etc/vtiversion.info'):                    
#                fail = '/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/usedskin.py' 
#                f = open(fail, 'r')
#                content = f.read()
#                f.close()                            
#                localfile2 = '/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/usedskin.py'
#                temp_file2 = open(localfile2, 'w')
#                temp_file2.write(content.replace('selektor.png', 'slekvti.png'))
#                temp_file2.close()                             
                self.restareE2() 
            else:
                self.restareE2()

    def restareE2(self):
        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, _('GUI needs a restart.\nDo you want to Restart the GUI now?'), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()


class BlocUnblockImageSkin(Screen):
    __module__ = __name__
    skin = """<screen name="Skin tool" title="Skin tool" position="center,center" size="856,657">            
          <widget name="lab1" position="20,5" size="820,130" font="baslk;30" halign="center" valign="center" transparent="1" foregroundColor="#00ffa500" />                      
          <widget source="list" render="Listbox" itemHeight="43" font="Regular;21" position="25,155" zPosition="1" size="815,430" scrollbarMode="showOnDemand" transparent="1">           
          <convert type="StringList" font="Regular;43" />           
          </widget>           
          <ePixmap position="172,609" size="37,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />                
          <widget name="key_red" position="224,611" zPosition="2" size="611,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" />                
          </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Block or unblock the neoboot skin display in the system skin.'))    
        self['key_red'] = Label(_('Block or unlock skins.'))              
        self['list'] = List([])
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.restareE2,
         'red': self.deleteback})         
        self.backupdir = '/usr/share/enigma2'
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        self.backupdir = '/usr/share/enigma2'
        if pathExists(self.backupdir) == 0 and createDir(self.backupdir):
            pass
            
        imageslist = []
        for fn in listdir(self.backupdir):
            imageslist.append(fn)

        self['list'].list = imageslist

    def deleteback(self):
        image = self['list'].getCurrent()
        self.delimage = image.strip()
        if fileExists(self.backupdir + '/' + self.delimage + '/skin.xml'):
            self.deleteback2()                                             
        else:
            self.myClose(_('Sorry, not find skin neoboot.'))

    def deleteback2(self):
        image = self['list'].getCurrent()
        if image:
            self.delimage = image.strip()
            message = (_('Select Yes to lock or No to unlock.\n  %s     ?') % image )                                    
            ybox = self.session.openWithCallback(self.Block_Unlock_Skin, MessageBox, message, MessageBox.TYPE_YESNO)
            ybox.setTitle(_('Confirmation...'))

    def Block_Unlock_Skin(self, answer):
        if answer is True:    
                fail = self.backupdir + '/' + self.delimage + '/skin.xml'
                f = open(fail, 'r')
                content = f.read()
                f.close() 
                localfile2 = self.backupdir + '/' + self.delimage + '/skin.xml'           
                temp_file2 = open(localfile2, 'w')
                temp_file2.write(content.replace('NeoBootImageChoose', 'neoBootImageChoose'))
                temp_file2.close()                                                                     
        else: 
                fail = self.backupdir + '/' + self.delimage + '/skin.xml'
                f = open(fail, 'r')
                content = f.read()
                f.close() 
                localfile2 = self.backupdir + '/' + self.delimage + '/skin.xml'           
                temp_file2 = open(localfile2, 'w')
                temp_file2.write(content.replace('neoBootImageChoose', 'NeoBootImageChoose'))
                temp_file2.close()                                              


    def restareE2(self):
        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, _('GUI needs a restart.\nDo you want to Restart the GUI now?'), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def myClose(self, message):
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)        
            self.close()


class InternalFlash(Screen):
    __module__ = __name__
    skin = """<screen name="InternalFlash" title="NeoBoot - Internal Flash " position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Install software internal flash memory in media'))
        self['key_red'] = Label(_('Start - Red'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.mountIF})
         
    def mountIF(self):
        if fileExists('/.multinfo'):
            self.mountinternalflash()                                            
        else:
            self.myClose(_('Sorry, the operation is not possible from Flash'))
            self.close()

    def mountinternalflash(self):
            if fileExists('/.multinfo') and getCPUtype() == 'ARMv7':           
                if os.path.exists('/proc/stb/info/boxtype'):
                    if getBoxHostName == 'sf4008':  #getCPUSoC() == 'bcm7251'  
                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p4 /media/InternalFlash')  

                if os.path.exists('/proc/stb/info/boxtype'):
                    if getBoxHostName == 'et1x000': #getCPUSoC() == 'bcm7251' or   
                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p4 /media/InternalFlash')  

                if os.path.exists('/proc/stb/info/boxtype'):
                    if getBoxHostName == 'ax51': #getCPUSoC() == 'bcm7251s' or   
                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p4 /media/InternalFlash')  

                if os.path.exists('/proc/stb/info/boxtype'):
                    if getCPUSoC() == 'bcm7251s' or getBoxHostName() == 'h7' or getBoxHostName() == 'zgemmah7' :   
                         os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p3 /media/InternalFlash')

                if os.path.exists('/proc/stb/info/boxtype'):
                    if getBoxHostName() == 'zgemmah9s':   
                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p7 /media/InternalFlash')
                    
#                if os.path.exists('/proc/stb/info/boxtype'):
#                    if getBoxHostName() == 'zgemmah9combo':   
#                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p7 /media/InternalFlash')                    

                if getBoxHostName == 'sf8008':   
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p13 /media/InternalFlash')  

                if getBoxHostName == 'ax60':   
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p21 /media/InternalFlash')

                if getBoxHostName() == 'ustym4kpro' or getTunerModel() ==  'ustym4kpro':   
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p13 /media/InternalFlash')

                if os.path.exists('/proc/stb/info/model'):
                    if getTunerModel() == 'dm900' or getCPUSoC() == 'BCM97252SSFF':   
                        os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p2 /media/InternalFlash')
                    
                if  getBoxVuModel() == 'uno4kse' or getBoxVuModel() == 'uno4k'  or  getBoxVuModel() == 'ultimo4k' or  getBoxVuModel() == 'solo4k':
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p4 /media/InternalFlash')

                if  getBoxVuModel() == 'zero4k':
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p7 /media/InternalFlash')

                if  getBoxVuModel() == 'duo4k':               
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p9 /media/InternalFlash')

                if  getBoxVuModel() == 'duo4kse':               
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p9 /media/InternalFlash')                    

                if getCPUSoC() == 'bcm7252s' or getBoxHostName() == 'gbquad4k':
                    os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p5 /media/InternalFlash')

                #if getBoxHostName == 'osmio4k':
                    #os.system('mkdir -p /media/InternalFlash; mount /dev/mmcblk0p5 /media/InternalFlash')

                else:
                    self.myClose(_('Your image flash cannot be mounted.'))

            if fileExists('/media/InternalFlash/etc/init.d/neobootmount.sh'):
                os.system('rm -f /media/InternalFlash/etc/init.d/neobootmount.sh;')

            self.myClose(_('Your image flash is mounted in the media location'))

    def myClose(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
        self.close()



class DeletingLanguages(Screen):
    __module__ = __name__
    skin = """ <screen name="DeletingLanguages" title="Deleting Languages" position="center,center" size="850,647">            
          <widget name="lab1" position="20,73" size="820,50" font="baslk;30" halign="center" valign="center" transparent="1" foregroundColor="#00ffa500" />                      
          <widget source="list" render="Listbox" itemHeight="40" font="Regular;21" position="25,142" zPosition="1" size="815,416" scrollbarMode="showOnDemand" transparent="1">           
          <convert type="StringList" font="Regular;35" />           
          </widget>           
          <ePixmap position="107,588" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />                
          <widget name="key_red" position="153,588" zPosition="2" size="368,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" />                
          </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Select to delete.'))
        self['key_red'] = Label(_('Delete file'))              
        self['list'] = List([])
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'ok': self.deleteback,
         'red': self.deleteback})         
        self.backupdir = '/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/locale'
        self.onShow.append(self.updateInfo)

    def updateInfo(self):
        self.backupdir = '/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/locale'
        if pathExists(self.backupdir) == 0 and createDir(self.backupdir):
            pass
            
        imageslist = []
        for fn in listdir(self.backupdir):
            imageslist.append(fn)

        self['list'].list = imageslist

    def deleteback(self):
        image = self['list'].getCurrent()
        if image:
            self.delimage = image.strip()
            message = (_('File:  %s  remove ?') % image )                                    
            ybox = self.session.openWithCallback(self.dodeleteback, MessageBox, message, MessageBox.TYPE_YESNO)
            ybox.setTitle(_('Confirmation of Deletion...'))

    def dodeleteback(self, answer):
        if answer is True:
            cmd = "echo -e '\n\n%s '" % _('NeoBoot - deleting backup files .....')
            cmd1 = 'rm -fR ' + self.backupdir + '/' + self.delimage
            self.session.open(Console, _('NeoBoot: Backup files deleted!'), [cmd, cmd1])
            self.updateInfo()
        else:
            self.close()


class ATVcamfeed(Screen):
    __module__ = __name__
    skin = """<screen name="ATV add cam feed" title="Password change" position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Add Cam dowloand from feed.'))
        self['key_red'] = Label(_('Start'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.addcamatv})

    def addcamatv(self):
        if getImageATv() == 'okfeedCAMatv':           
            cmd = "echo -e '\n\n%s '" % _('NeoBoot - ATV add cam feed ...')
            cmd1 = 'wget -O - -q http://updates.mynonpublic.com/oea/feed | bash' 
            self.session.open(Console, _('NeoBoot: Cams feed add...'), [cmd, cmd1])

        elif getImageATv() != 'okfeedCAMatv': 
            self.myClose(_('Sorry, is not image Open ATV !!!'))

    def myClose(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
        self.close()
        
        
class TunerInfo(Screen):
    __module__ = __name__
    skin = """<screen name="TunerInfo" title="NeoBoot - Sat Tuners " position="center,center" size="700,300" flags="wfNoBorder">
        <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1" />
        <ePixmap position="200,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
        <widget name="key_red" position="250,250" zPosition="2" size="280,35" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" foregroundColor="red" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('List of supported stb.'))
        self['key_red'] = Label(_('Start - Red'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.iNFO})
         
    def iNFO(self):
        try:
            cmd = ' cat ' +LinkNeoBoot+ '/stbinfo'
            cmd1 = ''
            self.session.openWithCallback(self.close, Console, _('NeoBoot....'), [cmd,
                     cmd1]) 
            self.close()

        except:
            False


class MultiBootMyHelp(Screen):
    if isFHD():
        skin = """<screen name="MultiBootMyHelp" position="center,center" size="1920,1080" title="NeoBoot - Opis" flags="wfNoBorder">
        <eLabel text="NeoBoot My Help" font="baslk; 35" position="69,66" size="1777,96" halign="center" foregroundColor="#bab329" backgroundColor="black" transparent="1" />
        <widget name="lab1" position="69,162" size="1780,885" font="baslk;35" />
        </screen>"""
    else:
        skin = '<screen name="MultiBootMyHelp" position="center,center" size="1280,720" title="NeoBoot - Opis">\n<widget name="lab1" position="18,19" size="1249,615" font="baslk;20" />\n</screen>'
    __module__ = __name__

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = ScrollLabel('')
        self['actions'] = ActionMap(['WizardActions', 'ColorActions', 'DirectionActions'], {'back': self.close,
         'ok': self.close,
         'up': self['lab1'].pageUp,
         'left': self['lab1'].pageUp,
         'down': self['lab1'].pageDown,
         'right': self['lab1'].pageDown})
        self['lab1'].hide()
        self.updatetext()

    def updatetext(self):
        message = ''
        message += 'NeoBoot Version ' + PLUGINVERSION + '  Enigma2\n\n'
        message += 'NeoBoot is based on EGAMIBoot < mod by gutosie >\n\n'
        message += 'EGAMIBoot author allowed neoboot development and editing - Thanks\n\n'
        message += 'nfidump by gutemine - Thanks\n\n'
        message += 'ubi_reader by Jason Pruitt  - Thanks\n\n'
        message += 'Translation by gutosie and other people!\n\n'
        message += _('Thank you to everyone not here for helping to improve NeoBoot \n\n')
        message += _('Successful fun :)\n\n')                      
        self['lab1'].show()
        self['lab1'].setText(message)


###______\\\\\\----for plugin----////_____###

class MyHelpNeo(Screen):
    if isFHD():
        skin = """<screen position="center,center" size="1820,840" title="NeoBoot - INFORMATION">
        <widget name="lab1" position="69,134" size="1780,913" font="tasat;25" backgroundColor="black" transparent="1" />
        </screen>"""
    else:
        skin = """<screen position="center,center" size="1180,620" title="NeoBoot - INFORMATION">
        <widget name="lab1" position="18,19" size="1249,615" font="baslk;20" backgroundColor="black" transparent="1" />
        </screen>"""

    __module__ = __name__

    def __init__(self, session):		
        Screen.__init__(self, session)
        self['lab1'] = ScrollLabel('')
        self['actions'] = ActionMap(['WizardActions', 'ColorActions', 'DirectionActions'], {'back': self.close,
         'ok': self.close,
         'up': self['lab1'].pageUp,
         'left': self['lab1'].pageUp,
         'down': self['lab1'].pageDown,
         'right': self['lab1'].pageDown})
        self['lab1'].hide()
        self.updatetext()

    def updatetext(self):		
        message = _('NeoBoot Ver. ' + PLUGINVERSION + '  Enigma2\n\nDuring the entire installation process does not restart the receiver !!!\n\n')
        message += _('NeoBoot Ver. updates ' + UPDATEVERSION + '  \n\n')
        message = _('For proper operation NeoBota type device is required USB stick or HDD, formatted on your system files Linux ext3 or ext4..\n\n')
        message += _('1. If you do not have a media formatted with the ext3 or ext4 is open to the Device Manager <Initialize>, select the drive and format it.\n\n')
        message += _('2. Go to the device manager and install correctly hdd and usb ...\n\n')
        message += _('3. Install NeoBota on the selected device.\n\n')
        message += _('4. Install the needed packages...\n\n')
        message += _('5. For proper installation NenoBota receiver must be connected to the Internet.\n\n')
        message += _('6. In the event of a problem with the installation cancel and  inform the author of the plug of a problem.\n\n')
        message += _('Buy a satellite tuner in the store: http://www.expert-tvsat.com/\n')   
        message += _('Have fun !!!')             
        self['lab1'].show()
        self['lab1'].setText(message)


class Opis(Screen):
    if isFHD():
        skin = """<screen position="center,center" size="1920,1080" flags="wfNoBorder"><ePixmap position="0,0" zPosition="-1" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/frame_base-fs8.png"  /><widget source="session.VideoPicture" render="Pig" position=" 1253,134" size="556,313" zPosition="3" backgroundColor="#ff000000"/><eLabel text="INFORMATION NeoBoot" position="340,50"  size="500,55" font="baslk;40" halign="left" foregroundColor="#58bcff" backgroundColor="black" transparent="1"/><widget name="key_red" position="30,950" size="430,50" zPosition="1" font="baslk; 30" halign="center" backgroundColor="red" transparent="1" foregroundColor="#ffffff" /><ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/scroll.png" position="1144,160" size="26,685" zPosition="5" alphatest="blend"/><ePixmap position="1350,750" zPosition="1" size="400,241" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/matrixhd.png" /> <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red25.png" position="100,1000" size="230,36" alphatest="blend" /><widget name="lab1" position="100,160" size="1070,680" font="baslk; 30"  backgroundColor="black" transparent="1" /></screen>"""                  		 		   		
    else:
        skin = """<screen position="center,center" size="1280,720" title="NeoBoot - INFORMATION"><ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/1frame_base-fs8.png"  position="0,0" zPosition="-1" size="1280,720" /><ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red25.png" position="50,680" size="230,36" alphatest="blend"  /><widget name="key_red" position="35,630" zPosition="1" size="270,40" font="Regular;20" halign="center" valign="center" backgroundColor="red" transparent="1" /><widget name="lab1" position="50,100" size="730,450" font="Regular;20" backgroundColor="black"  /><widget source="session.VideoPicture" render="Pig" position=" 836,89" size="370,208" zPosition="3" backgroundColor="#ff000000" /><widget source="Title" render="Label"  position="200,25" size="800,30" font="Regular;28" halign="left" foregroundColor="#58bcff" backgroundColor="transpBlack" transparent="1"/><ePixmap position="920,520" zPosition="1" size="228,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/1matrix.png" /><ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/scroll.png" position="754,100" size="26,455" zPosition="5" alphatest="blend" backgroundColor="black" transparent="1" /></screen>"""
    __module__ = __name__
    def __init__(self, session):		
        Screen.__init__(self, session)
        self['key_red'] = Label(_('Remove NeoBoot of STB'))
        self['lab1'] = ScrollLabel('')
        self['actions'] = ActionMap(['WizardActions', 'ColorActions', 'DirectionActions'], {'back': self.close,
         'red': self.delete,
         'ok': self.close,
         'up': self['lab1'].pageUp,
         'left': self['lab1'].pageUp,
         'down': self['lab1'].pageDown,
         'right': self['lab1'].pageDown})
        self['lab1'].hide()
        self.updatetext()

    def updatetext(self):		
        message = _('NeoBoot Ver. ' + PLUGINVERSION + '\n\n')
        message += _('NeoBoot Ver. updates ' + UPDATEVERSION + '\n\n')
        message += _('1. Requirements: For proper operation of the device NeoBota are required USB stick or HDD.\n\n')
        message += _('2. NeoBot is fully automated\n\n')
        message += _('3. To install the new software in multiboot, you must send the software file compressed in zip format via ftp to the ImagesUpload directory, or download from the network.\n\n')
        message += _('4. For proper installation and operation of additional image multiboot, use only the image intended for your receiver. !!!\n\n')
        message += _('5. By installing the multiboot images of a different type than for your model STB DOING THIS AT YOUR OWN RISK !!!\n\n')
        message += _('6. The installed to multiboot images, it is not indicated update to a newer version.\n\n')
        message += _('The authors plug NeoBot not liable for damage a receiver, NeoBoota incorrect use or installation of unauthorized additions or images.!!!\n\n')
        message += _('Have fun !!!')
        message += _('\nCompletely uninstall NeoBota: \nIf you think NeoBot not you need it, you can uninstall it.\nTo uninstall now press the red button on the remote control.\n\n')
        self['lab1'].show()
        self['lab1'].setText(message)

    def delete(self):		
        message = _('Are you sure you want to completely remove NeoBoota of your image?\n\nIf you choose so all directories NeoBoota will be removed.\nA restore the original image settings Flash.')
        ybox = self.session.openWithCallback(self.mbdelete, MessageBox, message, MessageBox.TYPE_YESNO)
        ybox.setTitle(_('Removed successfully.'))

    def mbdelete(self, answer):		
        if answer is True:                                                                
            if fileExists('/etc/fstab.org'):
                system('rm -r /etc/fstab; mv /etc/fstab.org /etc/fstab') 
            if fileExists('/etc/init.d/volatile-media.sh.org'):
                system(' mv /etc/init.d/volatile-media.sh.org /etc/init.d/volatile-media.sh; rm -r /etc/init.d/volatile-media.sh.org; chmod 755 /etc/init.d/volatile-media.sh ')                                                                 
            if os.path.isfile('%sImageBoot/.neonextboot' % getNeoLocation()): 
                os.system('rm -f /etc/neoimage; rm -f /etc/imageboot; rm -f %sImageBoot/.neonextboot; rm -f %sImageBoot/.version; rm -f %sImageBoot/.Flash; ' % (getNeoLocation(), getNeoLocation(), getNeoLocation()) )
            if os.path.isfile('%sImagesUpload/.kernel ' % getNeoLocation()): 
                os.system('rm -r %sImagesUpload/.kernel' % getNeoLocation())
            cmd = "echo -e '\n\n%s '" % _('Recovering setting....\n')
            cmd1 = 'rm -R ' + LinkNeoBoot + '' 
            cmd2 = 'rm -R /sbin/neoinit*'                                    
            cmd3 = 'ln -sfn /sbin/init.sysvinit /sbin/init'     
            cmd4 = 'opkg install --force-maintainer --force-reinstall --force-overwrite --force-downgrade volatile-media; sleep 10; PATH=/sbin:/bin:/usr/sbin:/usr/bin; echo -n "Rebooting... "; reboot -d -f'  
            self.session.open(Console, _('NeoBot was removed !!! \nThe changes will be visible only after complete restart of the receiver.'), [cmd,
             cmd1,
             cmd2,
             cmd3,
             cmd4,])
            self.close()
        else:
            self.close()            

class ReinstallKernel(Screen):
    __module__ = __name__

    skin = """<screen name="ReinstallKernel" title="Module kernel" position="center,center" size="700,300" >
    <widget name="lab1" position="20,20" size="660,210" font="baslk;25" halign="center" valign="center" transparent="1"/>
    <ePixmap position="210,250" size="34,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/images/red.png" alphatest="blend" zPosition="1" />
    <widget name="key_red" position="250,250" zPosition="2" size="280,40" font="baslk;30" halign="left" valign="center" backgroundColor="red" transparent="1" />
    </screen>"""                                                                            

    def __init__(self, session):
        Screen.__init__(self, session)
        self['lab1'] = Label(_('Re-installing the kernel. \n\nInstall?'))
        self['key_red'] = Label(_('Installation'))
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.close,
         'red': self.InfoCheck})

    def InfoCheck(self):
        if fileExists('/.multinfo'):
            if getCPUtype() == 'MIPS':
                if not fileExists( '/boot/' + getBoxHostName() + '.vmlinux.gz'):
                    mess = _('Update available only from the image Flash.')
                    self.session.open(MessageBox, mess, MessageBox.TYPE_INFO)
                else:
                    self.kernel_update()

            elif getCPUtype() == 'ARMv7':
                if not fileExists('/boot/zImage.' + getBoxHostName() + ''):
                    mess = _('Update available only from the image Flash.')
                    self.session.open(MessageBox, mess, MessageBox.TYPE_INFO)
                else:
                    self.kernel_update()                                            

        else:
            self.kernel_update()

    def kernel_update(self):
                os.system('echo "Flash "  > ' + getNeoLocation() + 'ImageBoot/.neonextboot')
                out = open('' + getNeoLocation() + 'ImagesUpload/.kernel/used_flash_kernel', 'w')
                out.write('Used Kernel:  Flash')
                out.close()            
                cmd1 = 'rm -f /home/root/*.ipk; opkg download kernel-image; sleep 2; opkg install --force-maintainer --force-reinstall --force-overwrite --force-downgrade /home/root/*.ipk; opkg configure update-modules; rm -f /home/root/*.ipk'
                self.session.open(Console, _('NeoBoot....'), [cmd1])
                self.close()


def myboot(session, **kwargs):
    session.open(MBTools)


def Plugins(path, **kwargs):
    global pluginpath
    pluginpath = path
    return PluginDescriptor(name='NeoBoot', description='MENU NeoBoot', icon=None, where=PluginDescriptor.WHERE_PLUGINMENU, fnc=myboot)
